#include <stdio.h>

int main() {
    // Write C code here
    int num,first_digit,last_digit,middle_digit;
    printf("Enter the Three Digit Number");
    scanf("%d",&num);
    if(num<100 && num>999)
    {
        printf("Invalid Input Enter a Three Digit Number");
    }
    else
    {
        last_digit=num%10;
        middle_digit=(num/10)%10;
        int temp=num;
        while(temp>10)
        {
            temp=temp/10;
        }
        first_digit=temp;
        if(first_digit+last_digit==middle_digit)
        {
            printf("sum of First Digit and Last Digit is equal to Middle Digit");
        }
        else
        {
            printf("Sum of First and Last digit is not equal to Middile Digit");
        }
    }

    return 0;
}
