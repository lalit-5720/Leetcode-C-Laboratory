#include<stdio.h>
void main()
{
    float dist_squared,x,y;
    printf("Enter the Input for the X:");
    scanf("%f",&x);
    printf("Enter the Input for the Y:");
    scanf("%f",&y);
    dist_squared=(x*x)+(y*y);
    if(dist_squared<25)
    {
        printf("The Point Lies inside the Circle");
    }
    else if(dist_squared==25)
    {
        printf("The point lies on the Circle");
    }
    else
    {
        printf("The point lies outside the Circle");
    }
}
