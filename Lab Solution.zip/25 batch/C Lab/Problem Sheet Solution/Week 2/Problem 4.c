#include<stdio.h>
void main()
{
    int N,digits,sum_number=0,product_number=1;
    printf("Enter the Input as a 3 digit Number ");
    scanf("%d",&N);
    if(N<100||N>999)
    {
        printf("Invalid Integer, Enter the Three Digit Number");
    }
    else
    {
        int temp=N;
        while(temp>0)
        {
            digits=temp%10;
            sum_number+=digits;
            product_number*=digits;
            temp/=10;
        }
        if(sum_number==product_number)
        {
            printf("The Sum and Product is Equal of the number");
        }
        else
        {
            printf("The Sum and Product is not Equal of the Number");
        }
    }
}
