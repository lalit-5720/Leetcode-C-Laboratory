# include<stdio.h>
void main()
{
    int a[]={1,1,2},n=3,i;
    int arrSum=0,arrSqSum=0,actual_sum,actual_square,diff1,diff2,SumXY;
    int duplicate,missing;
    for(i=0;i<n;i++)
    {
        arrSum+=a[i];
        arrSqSum+=(a[i]*a[i]);
    }
    actual_sum= n*(n+1)/2;
    actual_square= n*(n+1)*((2*n)+1)/6;

    diff1=arrSum-actual_sum;
    diff2=arrSqSum-actual_square;


    SumXY=diff2/diff1;

    duplicate=(diff1+SumXY)/2;
    missing=duplicate-diff1;

    printf("Duplicate Number: %d",duplicate);
    printf("\nMissing Number: %d",missing);

}
