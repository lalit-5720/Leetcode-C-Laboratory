#include<stdio.h>
void main()
{
    int N,i;
    long long sum_number=0;
    printf("Enter the Number to Loop till the Sum");
    scanf("%d",&N);
    if(N>0)
    {
        for(i=1;i<=N;i++)
        {
            sum_number+=i*(N-i+1);
        }
        printf("Sum of the Number:%lld",sum_number);
    }
    else
    {
        printf("Enter the Positive Number");
    }
}
