# include<stdio.h>
void main()
{
    int num,den,n1,n2,d1,d2,new_num,new_den;
    printf("Sleppy's Technique Fraction\n");
    for(num=10;num<100;num++)
    {
        for(den=num+1;den<100;den++)
        {
           n1=num/10;
           n2=num%10;
           d1=den/10;
           d2=den%10;
           if(n2==d1 && n2!=0)
           {
               new_num=n1;
               new_den=d2;

               if(new_den!=0)
               {
                    if(num*new_den==den*new_num)
                   {
                       printf("%d/%d = %d/%d\n",num,den,new_num,new_den);
                   }
               }
           }
           if(n1==d2 && n1!=0)
           {
               new_num=n1;
               new_den=d2;

               if(new_den!=0)
               {
                   if(num*new_den==den*new_num)
                   {
                       printf("%d/%d = %d/%d",num,den,new_num,new_den);
                   }
               }
           }
        }
    }
}
