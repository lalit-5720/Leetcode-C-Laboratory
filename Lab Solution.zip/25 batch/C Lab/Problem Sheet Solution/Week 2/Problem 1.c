#include<stdio.h>
void main()
{
    int N,First_number=0,Last_number=0;
    printf("Enter the Number ");
    scanf("%d",&N);
    Last_number=N%10;
    if(N>0)
    {
        while(N>=10)
        {
            N=N/10;
        }
        First_number=N;
        if(First_number%Last_number==0)
        {
            printf("First Digit is the Multiple of the Last Digit");
        }
        else if(Last_number%First_number==0)
        {
            printf("Last Digit is the Multiple of the First Digit");
        }
        else if(First_number==0||Last_number==0)
        {
            printf("First/Last Number is 0");
        }
        else
        {
            printf("First Digit and the second Digit is not multiple of the other");
        }
    }
    else
    {
        printf("Enter the Positive Number");
    }
}
