#include<stdio.h>
void main()
{
    int x,n,result=1,i;
    float sum_series=0;
    printf("Enter the Base Number: ");
    scanf("%d",&x);
    printf("Enter the Terms to Calculate: ");
    scanf("%d",&n);
    for(i=1;i<n+1;i++)
    {
        result*=x;
        sum_series+=result;
    }
    printf("Sum of Series= %.2f",sum_series);
}
