#include <stdio.h>
#include <math.h>

// Function to calculate factorial
double factorial(int n) {
    double fact = 1.0;
    for (int i = 1; i <= n; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    double x, J0 = 0.0;
    int n;

    printf("Enter the value of x: ");
    scanf("%lf", &x);

    // Summation for first 20 terms
    for (n = 0; n < 20; n++) {
        double term = pow(-1, n) * pow(x/2.0, 2*n) / (pow(factorial(n), 2));
        J0 += term;
    }

    printf("J0(%lf) = %lf\n", x, J0);

    return 0;
}
