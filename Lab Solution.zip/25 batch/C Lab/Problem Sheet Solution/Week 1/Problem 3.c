#include<stdio.h>
void main()
{
int t;
float value1;
printf("Enter the User value t");
scanf("%d",&t);
if(0<t&&t<=2)
{
    value1=20;
    printf("The Value of p(t):%f",value1);
}
else if((13<t&&<=16)||(t>30))
{
    value1=4*(t+2);
    printf("The Value of p(t):%f",value1);
}
else
{
    value1=4*(t*t+2*t);
    printf("The Value of p(t):%f",value1);
}
}
