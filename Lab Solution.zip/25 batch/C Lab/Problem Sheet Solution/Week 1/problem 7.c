# include<stdio.h>
void main()
{
    int computer_stick,user_stick,total_stick=21;
    while(total_stick>1)
    {
        printf("Enter The Match Stick to be collected from 1 to 4 ");
        scanf("%d",&user_stick);
        if(user_stick>4 || user_stick<1)
        {
            printf("Invalid Stick Collection.Pick the Correct stick");
        }
        total_stick-=user_stick;
        // if(total_stick==1)
        // {
        //     printf("You Lose,Computer Wins as there is only one stick");
        // }
        computer_stick=5-user_stick;
        printf("Computer picked %d match stick(s)\n",computer_stick);
        total_stick-=computer_stick;
        if(total_stick==1)
        {
            printf("You Lose,Computer Wins as there is only one stick");
        }
    }
}
