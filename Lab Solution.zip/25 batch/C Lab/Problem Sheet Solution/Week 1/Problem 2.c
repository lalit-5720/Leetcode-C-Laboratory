#include<stdio.h>
#include<math.h>
void main()
{
    int a,b,c;
    float discriminant,root1,root2;
    printf("Enter the Coefficent of A");
    scanf("%d",&a);
    printf("Enter the Coefficent of B");
    scanf("%d",&b);
    printf("Enter the Coefficient of C");
    scanf("%d",&c);
    discriminant=(b*b)-(4*a*c);
    if (discriminant>=0)
    {
        printf("The roots are real and different");
        root1=(-b+sqrt(discriminant)/(2*a));
        root2=(-b-sqrt(discriminant)/(2*a));
        printf("The Two roots are %f and %f",root1,root2);
    }
    else if(discriminant==0)
    {
        printf("The Roots are same");
        root1=root2=(-b)/(2*a);
        printf("The Roots are equal and the root is:%d",root1);
    }
    else
    {
        printf("The number is complex");
    }
}
