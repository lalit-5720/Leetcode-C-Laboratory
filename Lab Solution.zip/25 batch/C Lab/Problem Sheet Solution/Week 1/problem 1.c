#include<stdio.h>
void main()
{
int x;
float formulaa;
printf("Enter the X value to calculate");
scanf("%d", &x);
formulaa=((x*x*x)-(2*x*x)+(x-6.3))/((x*x)+(0.05*x)+3.14);
printf("The answer for the following formula:%f",formulaa);
}
