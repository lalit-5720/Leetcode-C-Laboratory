#include<stdio.h>
void main()
{
    int number1,sum=0,i;
    printf("Enter the Number to check the perfect number");
    scanf("%d",&number1);
    printf("Factors for the number:\t");
    for(i=1;i<=number1/2;i++)
    {
        if(number1%i==0)
        {
            sum+=i;
            printf("%d ",i);
        }
    }
    if(number1==sum)
    {
        printf("\n%d is the perfect number",number1);
    }
}
