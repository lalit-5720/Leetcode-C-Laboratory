#include<stdio.h>

void main()
{
    int n;
    printf("Enter the Number to check the next palindrome number");
    scanf("%d",&n);
    int next=n+1;
    while(1)
    {
        int num=next,reversed=0,original=next;
        while(num>0)
        {
            reversed=reversed*10+(num%10);
            num/=10;
        }
        if(original==reversed)
        {
            printf("Next palindrome number of %d is %d",n,next);
            break;
        }
        next++;
    }
}