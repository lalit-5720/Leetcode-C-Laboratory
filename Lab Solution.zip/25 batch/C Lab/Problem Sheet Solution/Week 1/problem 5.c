#include<stdio.h>
#include<stdlib.h>
void main()
{
    int first_number,second_number,result;
    printf("Enter the First Number");
    scanf("%d",&first_number);
    printf("Enter the Second Number");
    scanf("%d",&second_number);
    result=((first_number+second_number)+(abs(first_number-second_number)))/2;
    printf("The Maximum Number is:%d",result);

}
