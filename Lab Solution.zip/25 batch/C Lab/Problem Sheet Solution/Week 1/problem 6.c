//#include <stdio.h>
//void main() {
//     int i, j, rows = 5;

//     for(i = 1; i <= rows; i++) {
//         for(j = 1; j <= i; j++) {
//             printf("*");
//         }
//         printf("\n");
//     }
//}


// #include<stdio.h>

// void main()
 //{
 //    int i, j, rows = 5;
//     for(i = 1; i <= rows; i++) {
//         for(j = 1; j <= rows - i; j++) {
//             printf(" ");
//         }
//         for(j = 1; j <= (2*i - 1); j++) {
 //            printf("*");
//         }
//         printf("\n");
//     }
// }

// #include <stdio.h>
// void main() {
//     int i, j, rows = 5;

//     // Upper pyramid
//     for(i = 1; i <= rows; i++) {
//         for(j = 1; j <= rows - i; j++) {
//             printf(" ");
//         }
//         for(j = 1; j <= (2*i - 1); j++) {
//             printf("*");
//         }
//         printf("\n");
//     }

//     // Lower inverted pyramid
//     for(i = rows - 1; i >= 1; i--) {
//         for(j = 1; j <= rows - i; j++) {
//             printf(" ");
//         }
//         for(j = 1; j <= (2*i - 1); j++) {
//             printf("*");
//         }
//         printf("\n");
//     }
// }

// #include <stdio.h>
// void main() {
//     int i, j, rows = 5;

//     // Upper half
//     for(i = 1; i <= rows; i++) {
//         for(j = 1; j <= i; j++) {
//             printf("*");
//         }
//         printf("\n");
//     }

//     // Lower half
//     for(i = rows - 1; i >= 1; i--) {
//         for(j = 1; j <= i; j++) {
//             printf("*");
//         }
//         printf("\n");
//     }
// }





