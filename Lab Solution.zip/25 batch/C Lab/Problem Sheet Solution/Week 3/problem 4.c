#include<stdio.h>
void main()
{
    int n,i,positive=0,negative=0,even_num=0,odd_num=0;
    printf("Enter the Size of the Array: ");
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++)
    {
        printf("Enter the %d number ",i+1);
        scanf("%d",&arr[i]);
    }
    for(i=0;i<n;i++)
    {
        if(arr[i]>0)
        {
            positive+=1;
            if(arr[i]%2==0)
            {
                even_num+=1;
            }
            else if(arr[i]%2==1)
            {
                odd_num+=1;
            }
        }
        else if(arr[i]<0)
        {
            negative+=1;
            if(arr[i]%2==0)
            {
                even_num+=1;
            }
            else if(arr[i]%2!=0)
            {
                odd_num+=1;
            }
        }
    }
    printf("Count of Positive Number in the Array: %d",positive);
    printf("\nCount of Negative Number in the Array: %d",negative);
    printf("\nCount of Even Number in the Array: %d",even_num);
    printf("\nCount of Odd Number in the Array:%d",odd_num);
}
