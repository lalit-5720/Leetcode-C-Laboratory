# include<stdio.h>
void main()
{
    int n,i;
    printf("Enter the Size of the Array: ");
    scanf("%d",&n);
    int arr[n];
    int hash[n];
    for(i=0;i<n;i++)
    {
        printf("Enter the %d Number: ",i+1);
        scanf("%d",&arr[i]);
    }
    printf("Duplicate Element in the List: ");
    for(i=0;i<n;i++)
    {
        if(hash[arr[i]]==1)
        {
            printf("%d ",arr[i]);
        }
        hash[arr[i]]=1;
    }
}
