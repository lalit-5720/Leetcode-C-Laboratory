#include<stdio.h>

void main()
{
    int n,i,j;
    printf("Enter the Size of the Array: ");
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++)
    {
        printf("Enter the %d Number",i+1);
        scanf("%d",&arr[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n-i;j++)
        {
            if(arr[j+1]>arr[j])
            {
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    printf("Ascending order Array:");
    for(i=n-1;i>=0;i--)
    {
        printf("%d ",arr[i]);
    }
    printf("\nDescending order Array:");
    for(i=0;i<n;i++)
    {
        printf("%d ",arr[i]);
    }
}
