#include<stdio.h>
void main()
{
    int n,search,i,flag=0;
    printf("Enter the Size of the Array ");
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++)
    {
        printf("Enter the %d Number ",i+1);
        scanf("%d",&arr[i]);
    }
    printf("Enter the Search Element: ");
    scanf("%d",&search);

    for(i=0;i<n;i++)
    {
        if(search==arr[i])
        {
            printf("%d is in the array",search);
            flag=1;
            break;
        }
    }
    if(flag==0)
    {
        printf("%d is not in the array",search);
    }
}
