#include<stdio.h>
void main()
{
    int n,i;
    printf("Enter the Size of the Array");
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++)
    {
        printf("Enter the %d Number",i+1);
        scanf("%d",&arr[i]);
    }
    int largest=arr[1],second_largest=arr[0];
    for(i=0;i<n;i++)
    {
        if(arr[i]>largest)
        {
            second_largest=largest;
            largest=arr[i];
        }
        else if(arr[i]>second_largest && arr[i]<largest)
        {
            second_largest=arr[i];
        }
    }
    if(second_largest!=largest)
    {
        printf("Second Largest in the Array: %d",second_largest);
    }
    else
    {
        printf("All the Numbers are Same");
    }
}
