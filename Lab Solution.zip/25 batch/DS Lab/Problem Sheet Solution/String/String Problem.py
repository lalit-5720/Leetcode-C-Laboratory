"""
1.Print the length of the last word
s="fly to the moon"
print(len(s.split(" ")[-1]))

"""
"""
2.Check whether the string is palindrome

s="A man,a plan, a canal:Panama"
word1=''.join([char for char in s if char.isalnum()])
if (word1[::-1].lower()==word1.lower()):
    print(True)
else:
    print(False)
"""
"""
3.Reverse the word and print it

word="the sky is blue"
splitted_word=word.split(" ")[::-1]
join_word=' '.join([char for char in splitted_word])
print(join_word)

"""

"""
5.Check whether the original letter is same as another letter

s=input("Enter the String ")
t=input("Enter Another String ")
if(sorted(s)==sorted(t)):
    print(True)
else:
    print(False)

"""
"""
4.Check whether Isomorphic String


str1 = "add"
str2 = "egg"
if len(str1) != len(str2):
    print(False) 
else:
    map1, map2 = {}, {}
    for i in range(len(str1)):
        ch1, ch2 = str1[i], str2[i]
        if ch1 not in map1:
            map1[ch1] = ch2
        if ch2 not in map2:
            map2[ch2] = ch1
        if map1[ch1] != ch2 or map2[ch2] != ch1:
            print(False) 
    print(True)
    print(map1)
"""



import re

s="3[a]2[bc]"
numeric=''.join([char for char in s if char.isnumeric()])
splitt=re.findall(r"\[(.*?)\]",s)
for i in range(len(splitt)):
    type_conv=int(numeric[i])
    print(splitt[i]*type_conv,end='')



