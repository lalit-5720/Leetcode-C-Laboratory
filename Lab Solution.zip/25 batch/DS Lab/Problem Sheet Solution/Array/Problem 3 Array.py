n=int(input("Enter the Size of the Array"))
arr=[]
flag=0
for i in range(n):
    arr1=int(input(f"Enter the {i+1} Number"))
    arr.append(arr1)
search_element=int(input("Enter the Search Element in the array"))
for i in range(n):
    if arr[i]==search_element:
        flag+=1
if(flag==1):
    print(f"{search_element} is in the Array")
else:
    print(f"{search_element} is not in the Array")