n=int(input("Enter the Size of the Array"))
arr=[]
key=int(input("Enter the rotate times"))
for i in range(n):
    arr1=int(input(f"Enet the {i+1} Number"))
    arr.append(arr1)
for i in range(key):
    first_arr=arr[0]
    for j in range(n-1):
        arr[j]=arr[j+1]
    arr[n-1]=first_arr

for i in range(n):
    print(arr[i],end=' ')
    