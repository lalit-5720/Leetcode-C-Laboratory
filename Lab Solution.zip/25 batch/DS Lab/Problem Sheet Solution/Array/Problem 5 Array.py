scores=[]
total_point=0
for i in range(8):
    n=float(input(f"Enter the {i+1} Number"))
    if(n<=10):
        scores.append(n)
    else:
        print("Enter the Positive Number or Less than 10")
        n=int(input(f"Enter the {i+1} Number"))
        scores.append(n)
lowest_score=scores[0]
highest_score=scores[0]

for i in range(8):
    total_point+=scores[i]
    if(lowest_score>scores[i]):
        lowest_score=scores[i]
    elif(highest_score<scores[i]):
        highest_score=scores[i]
print("Your Lowest Score:",lowest_score)
print("Your Highest Score:",highest_score)
print("Total Points:",total_point)
print("Avergae Points:",total_point/8)