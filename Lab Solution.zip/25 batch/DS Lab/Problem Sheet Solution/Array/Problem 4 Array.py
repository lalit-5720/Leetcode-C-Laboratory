n=int(input("Enter the Size of the Array"))
arr=[]
positive_number=negative_number=even_number=odd_number=0
for i in range(n):
    arnum=int(input(f"Enter the {i+1} Number"))
    arr.append(arnum)
print(arr)
for i in range(n):
    if(arr[i]>0):
        positive_number=positive_number+1
        if(arr[i]%2==0):
            even_number+=1
        if(arr[i]%2!=0):
            odd_number+=1
    elif(arr[i]<0):
        negative_number+=1
        if(arr[i]%2==0):
            even_number+=1
        if(arr[i]%2!=0):
            odd_number+=1
print("Positive Numbers in the List:",positive_number)
print("Negative Numbers in the List:",negative_number)
print("Even Numbers in the List:",even_number)
print("Odd Numbers in the List:",odd_number)
