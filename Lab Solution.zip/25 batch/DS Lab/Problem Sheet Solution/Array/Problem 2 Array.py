arr=[]
n=int(input("Enter the Size of the Array"))
for i in range(n):
    ar=int(input(f"Enter the {i+1} Number"))
    arr.append(ar)
for i in range(n):
    for j  in range(0,n):
        if(arr[i]<arr[j]):
            temp=arr[i]
            arr[i]=arr[j]
            arr[j]=temp
print("List from Ascending and Descending Order",arr)