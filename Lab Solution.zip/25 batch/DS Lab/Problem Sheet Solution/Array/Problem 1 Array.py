n=int(input("Enter the Number of Array Size"))
array=[]
for i in range(n):
    arr=int(input("Enter the Number"))
    array.append(arr)
# print(array)
sorted_array=sorted(array)
# print(sorted_array)
print("Second Largest Value:",sorted_array[-2])
