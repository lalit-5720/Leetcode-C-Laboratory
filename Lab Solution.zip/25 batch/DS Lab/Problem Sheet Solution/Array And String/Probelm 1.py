n=int(input("Enter the Size of the Array"))
arr=[]
composite_number=[]
for i in range(n):
    number=int(input(f"Enter the {i+1} Number"))
    arr.append(number)
for i in range(n):
    for j in range(2,arr[i]//2):
        if(arr[i]%j==0):
            composite_number.append(arr[i])
            break
print("Array Elements after removing prime number:",composite_number)