n=int(input("Enter the Size of the Array"))
k=int(input("Enter the Element"))
arr=[]
for i in range(n):
    number=int(input(f"Enter the {i+1} Number"))
    arr.append(number)
