n=int(input("Enter the Size of the Array"))
dlist=[]
list0=[]
list1=[]
list2=[]
print("Enter Only 0's,1's or 2's")
for i in range(n):
    number=int(input(f"Enter {i+1} Number"))
    dlist.append(number)
for i in range(n):
    if(dlist[i]==0):
        list0.append(dlist[i])
    elif(dlist[i]==1):
        list1.append(dlist[i])
    elif(dlist[i]==2):
        list2.append(dlist[i])
    else:
        print("The Number is not either 0,1,2")
final_list=list0+list1+list2
print(final_list)