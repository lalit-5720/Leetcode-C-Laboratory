n=int(input("Enter the Size of the array"))
arr=[]
for i in range(n):
    number=int(input(f"Enter the {i+1} Number"))
    arr.append(number)
print(len(arr))
position=int(input("Enter the position to split"))
for i in range(position):
    first_arr=arr[0]
    for j in range(n-1):
        arr[j]=arr[j+1]
    arr[n-1]=first_arr
print(arr)